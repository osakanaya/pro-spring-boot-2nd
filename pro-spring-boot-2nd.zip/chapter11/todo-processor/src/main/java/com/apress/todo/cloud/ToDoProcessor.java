package com.apress.todo.cloud;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Processor;
import org.springframework.messaging.handler.annotation.SendTo;

import com.apress.todo.domain.ToDo;

@EnableBinding(Processor.class)
public class ToDoProcessor {
	
	private Logger logger = LoggerFactory.getLogger(ToDoProcessor.class);
	
	@StreamListener(Processor.INPUT)
	@SendTo(Processor.OUTPUT)
	public String transformToUpperCase(ToDo message) {
		logger.info("Processing >>> {}", message);
		
		message.setModified(LocalDateTime.now());
		
		StringBuilder builder = new StringBuilder("Congrats! Your TODO: ");
		builder.append(message.getDescription().toUpperCase());
		builder.append(" was completed! at ");
		builder.append(message.getModified());
		
		return builder.toString();
	}

}
