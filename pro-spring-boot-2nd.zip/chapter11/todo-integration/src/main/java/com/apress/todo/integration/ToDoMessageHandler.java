package com.apress.todo.integration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.apress.todo.domain.ToDo;

@Component
public class ToDoMessageHandler {
	private Logger logger = LoggerFactory.getLogger(ToDoMessageHandler.class);
	
	public void process(ToDo toDo) {
		logger.info(">>> {}", toDo);
	}
}
