package com.apress.todo.domain;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

public class ToDo {

    private String id;
    private String description;
    private LocalDateTime created;
    private LocalDateTime modified;
    private boolean completed;

    public ToDo() {
    	this.id = UUID.randomUUID().toString();
    	this.created = LocalDateTime.now();
    	this.modified = LocalDateTime.now();
    }
    
    public ToDo(String description) {
        this();
        this.description = description;
    }
    
    public ToDo(String description, boolean completed) {
    	this(description);
    	this.completed = completed;
    }

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDateTime getCreated() {
		return created;
	}

	public void setCreated(LocalDateTime created) {
		this.created = created;
	}

	public LocalDateTime getModified() {
		return modified;
	}

	public void setModified(LocalDateTime modified) {
		this.modified = modified;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	@Override
	public int hashCode() {
		return Objects.hash(completed, created, description, id, modified);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ToDo other = (ToDo) obj;
		return completed == other.completed && Objects.equals(created, other.created)
				&& Objects.equals(description, other.description) && Objects.equals(id, other.id)
				&& Objects.equals(modified, other.modified);
	}

	@Override
	public String toString() {
		return "ToDo [id=" + id + ", description=" + description + ", created=" + created + ", modified=" + modified
				+ ", completed=" + completed + "]";
	}
}