package com.apress.todo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoCloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoCloudApplication.class, args);
	}

}
