package com.apress.todo.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

@Data
@ConfigurationProperties(prefix = "todo.mail")
public class ToDoProperties {
    private String from;
    private String to;
    private String subject;
    private String host;
    private String username;
    private String password;
    private Integer port;
}
