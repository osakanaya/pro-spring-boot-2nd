package com.apress.todo.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Component;

import com.apress.todo.config.ToDoProperties;

@Component
public class ToDoMailMessageConverter implements Converter<byte[], SimpleMailMessage> {

	private ToDoProperties props;
	
	public ToDoMailMessageConverter(ToDoProperties props) {
		this.props = props;
	}
	
	@Override
	public SimpleMailMessage convert(byte[] source) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom(this.props.getFrom());
		message.setTo(this.props.getTo());
		message.setSubject(this.props.getSubject());
		message.setText(new String(source));
		
		return message;
	}

}
