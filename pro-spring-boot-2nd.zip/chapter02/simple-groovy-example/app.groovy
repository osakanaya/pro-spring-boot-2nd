@RestController
class WebApp {
    @GetMapping("/")
    String welcome() {
        "<h1><font face='vernada'>Srping Boot Rocks!</font></h1>"
    }
}