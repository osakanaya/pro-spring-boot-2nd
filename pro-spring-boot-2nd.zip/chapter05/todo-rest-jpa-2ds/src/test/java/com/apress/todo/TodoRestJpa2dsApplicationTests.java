package com.apress.todo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoRestJpa2dsApplicationTests {

	@Test
	void contextLoads() {
	}

}
