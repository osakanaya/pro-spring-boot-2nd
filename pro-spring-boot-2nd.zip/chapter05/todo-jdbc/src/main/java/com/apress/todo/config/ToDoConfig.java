package com.apress.todo.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class ToDoConfig {

	@SuppressWarnings("unused")
	private Environment environment;
	
	public ToDoConfig(Environment environment) {
		this.environment = environment;
	}

}
