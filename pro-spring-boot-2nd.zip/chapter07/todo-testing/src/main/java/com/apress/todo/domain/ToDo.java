package com.apress.todo.domain;

import java.util.Objects;

public class ToDo {

	private String id = "my-id";
	private String description;
	private boolean completed;
	
	public ToDo() {}
	
	public ToDo(String description) {
		this.description = description;
	}
	
	public ToDo(String description, boolean completed) {
		this.description = description;
		this.completed = completed;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	@Override
	public int hashCode() {
		return Objects.hash(completed, description, id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ToDo other = (ToDo) obj;
		return completed == other.completed && Objects.equals(description, other.description)
				&& Objects.equals(id, other.id);
	}

	@Override
	public String toString() {
		return "ToDo [id=" + id + ", description=" + description + ", completed=" + completed + "]";
	}
	
}
