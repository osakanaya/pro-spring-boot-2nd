package com.apress.todo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.test.context.junit4.SpringRunner;

import com.apress.todo.domain.ToDo;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@JsonTest
public class ToDoJsonTest {

	@Autowired
	private JacksonTester<ToDo> json;
	
	@Test
	public void toDoSerializeTest() throws Exception {
		ToDo toDo = new ToDo("Read a book");
		
		assertThat(this.json.write(toDo)).isEqualToJson("todo.json");
		assertThat(this.json.write(toDo)).hasJsonPathValue("@.description");
		assertThat(this.json.write(toDo)).extractingJsonPathStringValue("@.description").isEqualTo("Read a book");
	}
	
	@Test
	public void toDoDeserializeTest() throws Exception {
        String content = "{\"description\":\"Read a book\",\"completed\": true }";

        assertThat(this.json.parse(content)).isEqualTo(new ToDo("Read a book", true));
        assertThat(this.json.parseObject(content).getDescription()).isEqualTo("Read a book");
	}
}
