package com.apress.todo.config;

import java.util.Objects;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "todo.authentication")
public class ToDoProperties {
	
	private String findByEmailUri;
	private String username;
	private String password;

	public ToDoProperties() {}

	public String getFindByEmailUri() {
		return findByEmailUri;
	}

	public void setFindByEmailUri(String findByEmailUri) {
		this.findByEmailUri = findByEmailUri;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public int hashCode() {
		return Objects.hash(findByEmailUri, password, username);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ToDoProperties other = (ToDoProperties) obj;
		return Objects.equals(findByEmailUri, other.findByEmailUri) && Objects.equals(password, other.password)
				&& Objects.equals(username, other.username);
	}

	@Override
	public String toString() {
		return "ToDoProperties [findByEmailUri=" + findByEmailUri + ", username=" + username + ", password=" + password
				+ "]";
	}
	
}
