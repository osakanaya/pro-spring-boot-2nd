insert into to_do (id,description,created,modified,completed)
values ('8a8080a365481fb00165481fbca90000', 'Read a Book','2018-08-17 07:42:44.136','2018-08-17 07:42:44.137',true);

insert into to_do (id,description,created,modified,completed)
values ('ebcf1850563c4de3b56813a52a95e930', 'Buy Movie Tickets','2018-08-17 09:50:10.126','2018-08-17 09:50:10.126',false);

insert into to_do (id,description,created,modified,completed)
values ('78269087206d472c894f3075031d8d6b', 'Clean my Room','2018-08-17 07:42:44.136','2018-08-17 07:42:44.137',false);
