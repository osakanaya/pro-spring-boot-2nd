package com.apress.directory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DirectoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
