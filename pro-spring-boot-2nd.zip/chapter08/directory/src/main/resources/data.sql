insert into person (id,name,email,password,role,enabled,birthday,created,modified)
values ('dc952d19ccfc4164b5eb0338d14a6619','Mark','mark@example.com','secret','USER',true,'1960-03-29','2018-08-17 07:42:44.136','2018-08-17 07:42:44.137');

insert into person (id,name,email,password,role,enabled,birthday,created,modified)
values ('02288a3b194e49ceb1803f27be5df457','Matt','matt@example.com','secret','USER',true,'1980-07-03','2018-08-17 07:42:44.136','2018-08-17 07:42:44.137');

insert into person (id,name,email,password,role,enabled,birthday,created,modified)
values ('4fe22e358d0e4e38b680eab91787f041','Mike','mike@example.com','secret','ADMIN',true,'19820-08-05','2018-08-17 07:42:44.136','2018-08-17 07:42:44.137');

insert into person (id,name,email,password,role,enabled,birthday,created,modified)
values ('84e6c4776dcc42369510c2692f129644','Dan','dan@example.com','secret','ADMIN',false,'1976-10-11','2018-08-17 07:42:44.136','2018-08-17 07:42:44.137');

insert into person (id,name,email,password,role,enabled,birthday,created,modified)
values ('03a0c396acee4f6cb52e3964c0274495','Administrator','admin@example.com','admin','ADMIN',true,'1978-12-22','2018-08-17 07:42:44.136','2018-08-17 07:42:44.137');
