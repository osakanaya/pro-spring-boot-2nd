package com.apress.todo.redis;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.apress.todo.domain.ToDo;

@Component
public class ToDoProducer {
	private static final Logger log = LoggerFactory.getLogger(ToDoProducer.class);

	private RedisTemplate<String, ToDo> redisTemplate;
	
	public ToDoProducer(RedisTemplate<String, ToDo> redisTemplate) {
		this.redisTemplate = redisTemplate;
	}
	
	public void sendTo(String topic, ToDo toDo) {
		this.redisTemplate.convertAndSend(topic, toDo);
		log.info("Producer> Message Sent");
	}
}
