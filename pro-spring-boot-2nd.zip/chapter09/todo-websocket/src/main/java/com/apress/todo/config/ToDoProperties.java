package com.apress.todo.config;

import java.util.Objects;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "todo.ws")
public class ToDoProperties {
	private String app = "/todo-api-ws";
	private String broker = "/todo";
	private String endpoint = "/stomp";
	
	public ToDoProperties() {}

	public String getApp() {
		return app;
	}

	public void setApp(String app) {
		this.app = app;
	}

	public String getBroker() {
		return broker;
	}

	public void setBroker(String broker) {
		this.broker = broker;
	}

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	@Override
	public int hashCode() {
		return Objects.hash(app, broker, endpoint);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ToDoProperties other = (ToDoProperties) obj;
		return Objects.equals(app, other.app) && Objects.equals(broker, other.broker)
				&& Objects.equals(endpoint, other.endpoint);
	}

	@Override
	public String toString() {
		return "ToDoPropertiees [app=" + app + ", broker=" + broker + ", endpoint=" + endpoint + "]";
	}
}
