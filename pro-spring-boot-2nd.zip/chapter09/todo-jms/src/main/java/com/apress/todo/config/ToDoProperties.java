package com.apress.todo.config;

import java.util.Objects;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "todo.jms")
public class ToDoProperties {
	private String destination;
	
	public ToDoProperties() {}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	@Override
	public int hashCode() {
		return Objects.hash(destination);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ToDoProperties other = (ToDoProperties) obj;
		return Objects.equals(destination, other.destination);
	}

	@Override
	public String toString() {
		return "ToDoProperties [destination=" + destination + "]";
	}
}
