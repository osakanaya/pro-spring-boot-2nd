package com.apress.todo.annotation;

public enum Algorithm {
	BCRYPT, PBKDF2
}
