package com.apress.todo.security;

import org.springframework.context.annotation.ImportSelector;
import org.springframework.core.annotation.AnnotationAttributes;
import org.springframework.core.type.AnnotationMetadata;

import com.apress.todo.annotation.Algorithm;
import com.apress.todo.annotation.EnableToDoSecurity;

public class ToDoSecurityConfiguration implements ImportSelector {

	@Override
	public String[] selectImports(AnnotationMetadata annotationMetadata) {
		
		AnnotationAttributes attributes = AnnotationAttributes.fromMap(
				annotationMetadata.getAnnotationAttributes(EnableToDoSecurity.class.getName(), false));
		
		Algorithm algorithm = attributes.getEnum("algorithm");
		
		switch (algorithm) {
			case PBKDF2:
				return new String[] {"com.apress.todo.security.Pbkdf2Encoder"};
			case BCRYPT:
			default:
			return new String[] {"com.apress.todo.security.BCryptEncoder"};
		}
	}

}
