package com.apress.todo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoWebfluxApplicationTests {

	@Test
	void contextLoads() {
	}

}
