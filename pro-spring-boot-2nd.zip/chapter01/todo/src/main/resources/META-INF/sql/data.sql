insert into todo values ('7fd921cfd2b64dc7b995633e8209f385','Buy Milk','2018-09-23 15:00:01','2018-09-23 15:00:01',false);
insert into todo values ('5820a4c2abe74f409da89217bf905a0c','Read a Book','2018-09-02 16:00:01','2018-09-02 16:00:01',false);
insert into todo values ('a44b6db26aef49e39d1b68622f55c347','Go to Spring One 2018','2018-09-18 12:00:00','2018-09-18 12:00:00',false);
