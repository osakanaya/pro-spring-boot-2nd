package com.apress.todo.client;

import java.util.Objects;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix="todo")
public class ToDoRestClientProperties {

	private String url;
	private String basePath;

	public ToDoRestClientProperties() {}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getBasePath() {
		return basePath;
	}

	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	@Override
	public int hashCode() {
		return Objects.hash(basePath, url);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ToDoRestClientProperties other = (ToDoRestClientProperties) obj;
		return Objects.equals(basePath, other.basePath) && Objects.equals(url, other.url);
	}

	@Override
	public String toString() {
		return "ToDoRestClientProperties [url=" + url + ", basePath=" + basePath + "]";
	}
	
}
